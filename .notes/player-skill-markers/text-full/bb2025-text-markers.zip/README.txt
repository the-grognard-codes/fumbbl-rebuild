BB2025 core text marker pack
108 SVG masters; 432 transparent PNG exports.
Outlined MUTP Chakra Petch Bold glyphs; approved round-2 style.
Three-letter frames: 88x96. Other frames: 72x96.
Use markers.json for identity/category/label mapping and export-index.json for dimensions and SHA-256 checksums.
Three-letter Small/Medium exports share the 20px readability floor.
Production pitch integration and the illustrated pack remain separate work.
