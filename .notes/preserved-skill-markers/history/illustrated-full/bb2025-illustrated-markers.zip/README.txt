BB2025 illustrated core marker pack
108 identities; 432 normalized PNG exports.
Masters 216x288; Small/Medium 15x20; Large 18x24.
20px illustrated floor; rendering still scales with player zoom.
Use markers.json for identity/category/asset mapping, export-index.json for dimensions/checksums.
Generated source images and earlier rounds remain in the repository and are excluded from this runtime-asset ZIP.
Generation records retain provenance paths; those original files are outside this archive.
Unique star abilities, stat changes, named temporary effects and numeric variants are excluded.
Production pitch integration remains a separate review checkpoint.
